# First-Message Onboard Template

Paste this into the first message of a new session along with your task.
No other docs needed unless noted.

---

## Context

Hearthfield is a Bevy/Rust pixel-art farming sim. 15 domains, ~20k LOC,
192 headless tests. Builds: `cargo check`, `cargo test --test headless`,
`cargo clippy -- -D warnings`. WASM: `./build_wasm.sh`.

## Rules

1. Scout with Sonnet minimum, never Haiku
2. Every sub-agent claim is [Assumed] until tool-verified
3. Wave cadence: Feature → Gate → Document → Harden → Graduate
4. Clamp scope after every worker: `bash scripts/clamp-scope.sh src/{domain}/`
5. Commit after every worker, fresh context per worker
6. Only [Observed] truths become tests or shipped fixes
7. Green gates ≠ shippable — always run Harden

## Leash

- Gate passes → ship without asking (Tier 1)
- Adjacent [Observed] bugs in same domain → fix + log (Tier 2)
- Cross-domain or design decisions → propose only (Tier 3)

## Task

[Describe what you want done here]

---

### When to also feed PLAYBOOK_v2.md:
- Tier M/C work with multiple workers across domains

### When to also feed STATE.md:
- Always (it's short and current)

### Docs you do NOT need to feed:
- AI Initiation Manual (vocabulary, not procedure — zero behavioral impact)
- Decision Field form (too heavy, never fires in practice)
- Anti-thrash repair protocol (redundant with normal retry behavior)
- Operating Kernel full version (CLAUDE.md v2 contains all actionable content)
- Operational Procedures (tier classification is in CLAUDE.md, rest is redundant)
