# Sub-Agent Playbook — Compact

Use for Tier M/C multi-worker dispatch. Tier S doesn't need this.

## The Core Problem

Mechanical gates always pass by Wave 3. A build that compiles, passes all tests,
and has zero clippy warnings can still have a completely broken player experience.
(Evidence: Precinct DLC — 15,815 LOC, 120 tests, all green, 6 player-journey breaks
undetected until final audit.)

## Contract Protocol

1. Freeze `src/shared/mod.rs` before dispatching workers
2. Checksum: `shasum -a 256 src/shared/mod.rs > .contract.sha256`
3. Workers import `crate::shared::*` — never define shared types locally
4. Verify after every worker: `shasum -a 256 -c .contract.sha256`

## Worker Dispatch

Each worker gets:
- **One domain scope** (e.g., `src/fishing/`)
- **Concrete deliverable** (e.g., "implement catch_fish system that reads FishingState and emits CatchEvent")
- **Explicit constraints:** no orchestration infra, no shared contract edits, no atlas index choices

After every worker:
1. `bash scripts/clamp-scope.sh src/{domain}/`
2. `cargo check && cargo test --test headless && cargo clippy -- -D warnings`
3. `git add -A && git commit`
4. If clamp breaks the fix → it's integration work, not domain work. Route accordingly.

## Reality Gates (Harden phase)

After structural gates pass, verify these experiential checks:

1. **Entrypoint:** Does the game boot to a playable state?
2. **First 60 seconds:** Can a new player walk, use a tool, interact with something?
3. **Asset reachability:** Are sprites, maps, and sounds loading (not placeholders)?
4. **Event connectivity:** Do player actions trigger expected downstream effects?
5. **Save/load roundtrip:** Does save→load preserve position, inventory, progress?

## Graduation

For each surface verified in Harden:
1. Name the invariant
2. Write a headless regression test
3. Add to gate suite
4. Track ungraduated items as P0/P1/P2

## Scouting Strategy

- Use **Sonnet minimum** for all scouting (not Haiku — 42% vs 83% accuracy)
- Every claim starts as [Assumed]
- Budget: expect 40-60% false positive rate even with Sonnet scouts
- One Sonnet verifier pass replaces two Haiku scouts + one verifier
