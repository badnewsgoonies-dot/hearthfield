# Delegation Architecture — Two-Layer Orchestration

## The Problem

The top-level agent (you, reading this) has two competing jobs:
1. **Talk to the user** — answer questions, take direction, report status
2. **Manage deep technical work** — audit, plan, implement, integrate

These don't mix. Deep work burns context. User communication needs responsiveness.
When you spawn workers directly, you become both manager and foreman — and you
drop balls on both.

## The Solution: You Are the Orchestra Conductor, Not the First Chair

```
┌─────────────────────────────────────┐
│           TOP-LEVEL AGENT           │
│  • Talks to user                    │
│  • Receives task                    │
│  • Spawns ONE foreman agent         │
│  • Monitors foreman status          │
│  • Reports results to user          │
│  • Makes Tier 3 decisions           │
│  • NEVER spawns workers directly    │
└──────────────┬──────────────────────┘
               │ spawns (general-purpose, Sonnet)
               ▼
┌─────────────────────────────────────┐
│          FOREMAN AGENT              │
│  • Gets: CLAUDE_v2, PLAYBOOK_v2,   │
│    STATE.md, and the task           │
│  • Owns the wave cadence            │
│  • Spawns workers in phases:        │
│    1. Scout agents (Sonnet explore) │
│    2. Verification pass             │
│    3. Implementation agents         │
│    4. Gate agents                   │
│    5. Integration                   │
│  • Returns: summary + commits       │
└──────────────┬──────────────────────┘
               │ spawns (explore, task, general-purpose)
               ▼
┌─────────────────────────────────────┐
│           WORKER AGENTS             │
│  • Single domain scope              │
│  • Clamped by scripts               │
│  • No cross-domain, no contract     │
│  • Report findings/changes back     │
└─────────────────────────────────────┘
```

## What Each Layer Does

### Top-Level Agent (YOU)

**DO:**
- Parse user intent
- Spawn a foreman with full context (CLAUDE_v2 + PLAYBOOK_v2 + STATE + task)
- Answer user questions while foreman works (use background mode)
- Review foreman output before reporting to user
- Make Tier 3 decisions the foreman escalates
- Update STATE.md at session end

**DON'T:**
- Spawn explore/task agents directly for implementation work
- Do deep code reading yourself (delegate to foreman)
- Burn context on 15-domain audits (that's foreman's job)
- Hold technical state — the foreman holds it

### Foreman Agent (general-purpose, Sonnet)

Gets this in its prompt:
```
You are the foreman. You own the full wave cadence.

Docs: [paste CLAUDE_v2.md] [paste PLAYBOOK_v2.md]
State: [paste STATE.md]
Task: [the actual work]

Execute the task through sub-agents. Follow wave cadence.
Report back: what was done, what was found, what needs decisions.
```

**DO:**
- Scout with Sonnet explore agents (parallel, batched)
- Verify all findings (tool-check, every claim starts [Assumed])
- Dispatch implementation workers (one per domain, clamped)
- Run gates after each worker
- Integrate cross-domain changes itself
- Return structured summary to top-level

**DON'T:**
- Talk to the user (only top-level does that)
- Make Tier 3 decisions (escalate to top-level)
- Skip Harden/Graduate phases

### Worker Agents (explore, task, general-purpose as needed)

- Single domain, single deliverable
- Scope-clamped mechanically
- No shared contract edits
- Report back to foreman, not top-level

## How This Changes the Onboard

The ONBOARD_TEMPLATE.md first-message stays the same for the user.

The change is internal: when you receive a task, instead of:
```
❌ Parse task → spawn 5 explore agents → verify → spawn fix agents → gate
```

You do:
```
✅ Parse task → spawn 1 foreman with full context → monitor → report to user
```

## When to Use Each Pattern

| Task | Pattern |
|------|---------|
| User asks a question | Answer directly (no foreman) |
| Single file fix (Tier S) | Do it yourself or one task agent |
| Multi-domain audit (Tier M) | Spawn foreman |
| Campaign build (Tier C) | Spawn foreman |
| User asks "what's the status?" | Check foreman, report |
| Foreman escalates a design choice | Ask user (Tier 3 leash) |

## Benefits

1. **You stay responsive** — user never waits while you're deep in code
2. **Context stays clean** — you don't burn 50k tokens on audit data
3. **Foreman has full context** — it gets the docs, not fragments
4. **Workers get proper specs** — foreman writes them, not you through telephone
5. **Long-horizon autonomy** — foreman can run a full wave while you chat
