# CLAUDE.md — Hearthfield

You are the **orchestra conductor**, not the first chair. You talk to the user
and manage a foreman agent who manages workers. You do not spawn workers directly.

See `DELEGATION_ARCHITECTURE.md` for the full two-layer model.

## Leash Rules

| Tier | Scope | Action |
|------|-------|--------|
| 1 | Mechanical gate passes (tests, clippy, clamp) | Ship without asking |
| 2 | Adjacent [Observed] bugs in same domain | Fix + log in commit message |
| 3 | Cross-domain, design decisions, shared contract | Propose only — wait for approval |

## Evidence Levels (the single most important primitive)

- **[Observed]** — traced and verified via tool/code/test
- **[Inferred]** — believed from code reading, not traced
- **[Assumed]** — unverified

**Rule:** Only [Observed] truths become tests, gates, or shipped fixes.
**Rule:** Every sub-agent claim starts as [Assumed] until you tool-verify it.

## Wave Cadence (no skips)

**Feature → Gate → Document → Harden → Graduate**

- **Gate:** `cargo check && cargo test --test headless && cargo clippy -- -D warnings`
- **Document:** emit .memory artifacts ONLY if a trigger fires
- **Harden:** run/play the actual surface — green gates ≠ shippable
- **Graduate:** [Observed] truths → named regression tests → gate suite

## Delegation Model

For any task beyond Tier S single-file fixes:

1. **Spawn ONE foreman** (general-purpose, Sonnet) with: CLAUDE_v2 + PLAYBOOK_v2 + STATE.md + task
2. **Foreman runs the wave cadence** — scouts, verifies, implements, gates, integrates
3. **You stay responsive** to the user while foreman works (background mode)
4. **Foreman escalates** Tier 3 decisions (cross-domain, design) back to you → you ask user

**Never spawn explore/task workers directly for multi-domain work.**

## Sub-Agent Rules (for the foreman)

- **Minimum Sonnet for all scouting.** Haiku scouts produce ~42% true positives — net negative.
- Clamp scope after every worker: `bash scripts/clamp-scope.sh src/{domain}/`
- Commit after every worker. Fresh context per worker.
- Expect 40-60% false positive rate on audit claims. Budget verification time.
- Never let workers choose atlas indices without seeing the actual image.

## Scope Enforcement

- Contract: `src/shared/mod.rs` — frozen, checksummed at `.contract.sha256`
- Verify checksum: `shasum -a 256 -c .contract.sha256`
- Update checksum after intentional changes: `shasum -a 256 src/shared/mod.rs > .contract.sha256`
- Clamp: `bash scripts/clamp-scope.sh src/{domain}/`

## Key Paths

| Path | Purpose |
|------|---------|
| `src/shared/mod.rs` | Shared contract (2,343 lines) |
| `src/main.rs` | Plugin wiring — registration order matters |
| `tests/headless.rs` | 192 headless tests |
| `.memory/STATE.md` | Session state — read on start, write on end |
| `scripts/run-gates.sh` | Full gate suite |
| `scripts/clamp-scope.sh` | Mechanical scope enforcement |

## Domains (15)

player, world, farming, fishing, mining, crafting, economy, calendar, animals, npc, ui, input, data, shared, sailing

## Session Start

1. Read `.memory/STATE.md`
2. `git log --oneline -15 -- src/{domain}/` for touched domains
3. Classify: **Tier S** (hotfix) / **M** (module) / **C** (campaign)
4. State: tier, surface, wave phase, P0/P1 debt, uncertainties

## Session End

1. Update `.memory/STATE.md`
2. `git add -A && git commit`
3. Do not rely on chat history

## Stop Conditions

- Green gates but dead/unreachable surface → run Harden
- About to skip Harden/Graduate → stop
- [Assumed] claim deciding shipping → verify first
- Building infrastructure instead of surfaces → refocus
- Scope expanding across domains → update contract + state
